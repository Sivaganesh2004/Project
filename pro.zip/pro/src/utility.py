def readToken():
    file = open("../resources/token.txt", "r")
    
    return file.readline()
